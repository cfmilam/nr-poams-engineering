## Objective

Build and test a pair of prepared endpoints whose exchange relationship can be interrogated after their preparation link is removed.

Direct Arrival approaches transport through **controlled endpoint adjacency**: prepare two physical organizations to exchange, retain their organization, and test whether that exchange can be selected and operated without the original connection. The opening experiment seeks an address-selective terminal response, accompanied by the corresponding source energy change.

A reproducible result would establish the experimental foundation for address-selective exchange devices. The immediate laboratory task is to deliver the preparation, isolation, phase-control and readout system, then conduct a blinded test.

## Physical construction

Use long-lived superconducting RF resonators with a removable, phase-controlled enrollment bridge. The bridge establishes and measures reciprocal exchange before isolation. A local boundary tuner then advances or retards the source's retained phase.

The first test uses three stations:

- **A — source:** jointly prepared with the enrolled receiver; carries the boundary tuner and local random-choice generator.
- **B — enrolled receiver:** shares the measured preparation history with A.
- **C — reference receiver:** independently prepared to match B's local frequency, phase, amplitude and loading, without A–C enrollment.

Each station has its own acquisition, timing reference and local records. The receiver comparison asks whether the response follows the prepared relationship.

The lead hardware has a concrete precedent: phase-controlled coupled SRF cavities with long loaded ringdown. [Wang et al., coupled-cavity apparatus](https://arxiv.org/html/2305.15662v2)

## Decisive trial

1. **Prepare.** Establish reciprocal A–B exchange. Bind the trial to a fresh terminal challenge mapped to measured physical settings. Independently prepare C.
2. **Isolate.** Remove the preparation drives and disconnect the bridge at both ends, with local terminations and recorded physical-break witnesses. Disconnect cross-station authentication, timing and feedback links.
3. **Hold.** Allow the measured switching and preparation transients to settle while retaining the endpoint states.
4. **Choose and act.** Generate a fresh random choice at A after isolation. Apply a calibrated positive or negative quarter-turn phase operation and restore the nominal resonance.
5. **Read.** Record continuous source and receiver traces over a fixed window. B and C execute the same autonomous acquisition regardless of A's choice.
6. **Compare.** Seal the raw records, release the source choices, and apply the predetermined analysis.

The primary measurement is the difference between B's and C's normalized energy changes, compared across the two source phase choices. In the seeded exchange model, opposite quarter-turns produce opposite energy redistribution between A and B. Record each station separately as well as the differential result.

The receivers learn the source choice only after acquisition is complete.

## Initial engineering targets

| Parameter | Starting target |
|---|---|
| Storage mode | 1.3 GHz-class superconducting resonator |
| Loaded quality factor | Approximately 1.5 billion in the assembled apparatus |
| Isolation guard | 20 ms, extended to cover measured transients |
| Source phase operation | ±π/2 within 5 ms; matched final frequency and amplitude |
| Observation window | 50 ms after the phase operation |
| Retained-state interval | 75 ms for this sequence |
| Relative phase uncertainty | At most π/6 across the retained-state interval |

The passive storage calculation gives an energy decay time of approximately 184 ms and about 66% energy retention over 75 ms. A 5 ms quarter-turn requires an average detuning of ±50 Hz.

Set the final timing and operating amplitude from measurements of the **complete assembly**, including tuner, switches, terminations and readout. Alternative resonator architectures are welcome where they improve retained phase, isolation or measurement sensitivity.

## Work packages

### 1. Establish the operating window

Measure loaded energy decay, phase holdover, mode purity, readout loading and tuner response. Demonstrate both phase-operation signs, restored final resonance and repeatable reset. Determine the interval available after actual disconnection and settling.

### 2. Calibrate exchange and isolation

With a known bridge present, recover weak exchange of measured strength, phase sign and delay. With it removed, characterize residual paths through calibrated RF, optical, electrical, mechanical, acoustic and thermal injections.

Include matched dummy actuation, real/sham disconnects and deliberate setting-bearing leaks. Meter receiver-local stores and readout inputs so triggered local release can be distinguished from transferred energy.

### 3. Run the blinded endpoint test

Freeze the operating settings, receiver statistic, timing window, sample allocation and control margins. Generate source choices after isolation, retain every scheduled trial, and analyze using the recorded randomization scheme.

Measure source depletion, terminal gain, port work, actuator/readout inputs and the differential loss budget. Report the response or exclusion bound in physical units with its measured uncertainty.

### 4. Establish selectivity and reproducibility

Swap enrollment between receivers while holding geometry fixed; then swap positions and electronics. Test phase reversal, detuning, retained-state erasure and re-enrollment. Repeat the result with an independently prepared apparatus.

These tests determine whether the effect follows the enrolled endpoint and which preparation sustains it.

## Requested laboratory proposal

Provide:

1. **Apparatus and team:** block diagram, responsible investigators, existing equipment and required additions. Price the third reference station separately.
2. **Performance plan:** achievable retention, phase-operation time, disconnect settling, isolation floor and energy sensitivity.
3. **Run plan:** calibration and injection program, blinded trial matrix, independent experimental unit, sample allocation and reset procedure.
4. **Deliverables:** complete raw records, calibration and uncertainty budgets, reproducible analysis, and an endpoint-response map or quantitative exclusion bound.
5. **Cost and schedule:** staged estimates for apparatus qualification, the first blinded run and replication.

The first milestone is a demonstrated **prepare–disconnect–hold–phase-operate–read** sequence at a stated sensitivity. That establishes the platform for the Direct Arrival experiment.

Supporting technical material: [experimental protocol](EXPERIMENTS.md) · [mechanism and predictions](MECHANISM.md).
