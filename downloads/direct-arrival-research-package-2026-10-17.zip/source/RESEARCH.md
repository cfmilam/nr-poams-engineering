## The engineering proposition

**Prepare a pair. Remove its ordinary connection. Test whether the pair can still exchange.**

Direct Arrival takes the relational account of space into the laboratory. Its first machine is a pair of long-lived, prepared endpoints with a controllable source boundary and an independently measured receiver. The technological objective is address-selective exchange: a physical operation chooses a prepared partner, and the source, receiver and support accounts record the corresponding completion.

The experiment begins with one sharply posed question: **does a newly chosen source operation change the enrolled receiver's record after the preparation bridge has been removed?** That question gives the program an actuator, an observable and a decisive comparison. A reproducible response would open a route to selected-endpoint sensing, communication and energy routing.

The proposed additional physical principle is **retained adjacency**: a qualified reciprocal preparation can leave a finite capacity for further two-ended exchange after the admitted bridge is removed. It is a hypothesis to test, not a consequence supplied by phase matching or the existing closure rules. The design names the extra interaction and measures it directly.

```{=html}
<div class="document-grid" aria-label="Research package documents">
<a class="document-card" href="direct-arrival-protocol.html"><strong>Full experimental protocol</strong><span>DA-0 through DA-7: apparatus, trials, controls, statistics, accounts and replication.</span></a>
<a class="document-card" href="direct-arrival-lab-brief.html"><strong>Laboratory development brief</strong><span>The first build, engineering targets, deliverables and requested cost/schedule proposal.</span></a>
<a class="document-card" href="downloads/direct-arrival-research-package-2026-10-17.zip" download><strong>Download the research package</strong><span>All three exhibits, source text, draft preregistration and reproducible design calculations.</span></a>
</div>
```

## The three-station bench

| Station | Physical role | What distinguishes it |
|---|---|---|
| **A — source** | Retained resonator with a local boundary tuner and fresh random-choice generator | Receives the late positive or negative phase operation |
| **B — enrolled receiver** | Retained resonator prepared through reciprocal exchange with A | Owns the witnessed A–B preparation history |
| **C — reference receiver** | Independently prepared resonator matched to B's local mode, energy, phase and loading | Has no A–C enrollment; tests whether matching alone explains the response |

Each station has autonomous timing, readout and storage. First characterize A–B exchange through a known ordinary bridge. Then remove preparation drives, disconnect the bridge at both ends, terminate the local stubs and witness the physical gap. Authentication, shared timing and feedback connections are also removed. The late source choice is generated only after isolation, and receiver acquisition proceeds independently of that choice.

<ol class="sequence" aria-label="Trial sequence">
<li><strong>Prepare</strong><span>Measure reciprocal A–B exchange; independently prepare C.</span></li>
<li><strong>Disconnect</strong><span>Remove the bridge and every live cross-station control path.</span></li>
<li><strong>Hold</strong><span>Let measured transients settle within the retained-state interval.</span></li>
<li><strong>Phase-operate</strong><span>Make a fresh local choice at A and apply +π/2 or −π/2.</span></li>
<li><strong>Read and seal</strong><span>Retain continuous A/B/C records; release choices only after acquisition is sealed.</span></li>
</ol>

The actuator is a local detuning pulse: temporarily change the source resonator's boundary, accumulate the required phase advance or retardation, and restore the nominal resonance. This acts on retained physical motion. A destination name or authentication hash does not substitute for that operation.

## A practical storage platform

**Long-lived superconducting radio-frequency resonators are the lead platform.** The useful interval must contain the physical disconnect, settling guard, source operation and receiver readout. Actual loaded phase retention is qualified on the complete assembly, including the tuner, switches and readout.

Published coupled-cavity work supplies a relevant connected control: 1.3 GHz resonators with loaded quality factors of approximately 1.53 and 2.56 billion and a phase-controlled coaxial bridge. It is a precedent for preparation and ringdown instrumentation, not a report of exchange after bridge removal. [Wang and colleagues](https://arxiv.org/html/2305.15662v2)

| Design quantity | Starting value | Engineering consequence |
|---|---|---|
| Mode and loaded quality factor | 1.3 GHz; Q ≈ 1.5 × 10⁹ | Passive energy decay time ≈ 184 ms |
| Isolation guard | 20 ms, enlarged for measured transients | Qualified before the late source choice |
| Source operation | ±π/2 within 5 ms | Average detuning ±50 Hz |
| Observation interval | 50 ms | Fixed before confirmation |
| Total retained interval | 75 ms | Passive energy survival ≈ 66.5% |
| Relative phase uncertainty | At most π/6 over 75 ms | Constant residual mismatch alone ≤ 1.11 Hz |

These are starting engineering targets. The laboratory selects the actual operating envelope from measured retention, isolation and sensitivity. Published long-lifetime SRF storage gives a second platform lead. [Romanenko and colleagues](https://arxiv.org/abs/1810.03703) YIG and high-Q mechanical storage remain alternatives if their assembled retention and isolation performance support the same trial. No local phase-persistence measurement is used as a witness of a remote interaction.

## Eight experiments, one decision chain

| ID | Question | Decisive intervention and record |
|---|---|---|
| **DA-0** | Does the complete instrument qualify? | Known bridge, real/sham breaks, phase steps and deliberate false-signal injections; measured operating window and artifact floor |
| **DA-1** | Does the late source choice affect the isolated receiver? | Random ±π/2 source operation; frozen enrolled-minus-reference energy contrast and independent source record |
| **DA-2** | Does the effect follow the enrolled partner? | Enrollment, position, electronics and address swaps; near-match, dummy and absent-terminal controls |
| **DA-3** | What preparation sustains it? | Phase, detuning and hold-time series; scrambling, discharge and re-enrollment; held-out response predictions |
| **DA-4** | Is there conserved transfer? | Passive receiver, source depletion, load work, readout/actuator inputs and loss budgets; angular momentum requires a qualified handed-mode witness |
| **DA-5** | What are its timing, route and distance dependence? | Baseline, shielding and ordinary-path manipulations; qualified latency and uncertainty; a separate front-timing experiment for any spacelike claim |
| **DA-6** | What organization can be transferred? | Source-private patterns, terminal reconstruction and source residuals; a separately designed quantum/custody benchmark follows classical state-description transfer |
| **DA-7** | Can another apparatus reproduce it? | Independent implementation of the locked experiment, controls and complete raw-data requirements |

DA-0 establishes the instrument. DA-1 supplies the first physical decision. Partner selection, mechanism, conservation, path discrimination and independent replication then determine what can be engineered. The current program covers prepared resonator endpoints; material payloads and living subjects are outside its scope.

## Entanglement and an operable relation

Bell experiments establish nonclassical joint correlations; entanglement alone does not let a source-local choice change a separated receiver's unconditional record. Our adopted Coherent Completion Kernel preserves that local-marginal rule. The proposed bench therefore tests for **a retained interaction**, not merely retained correlation. Coherent resonator preparation is not by itself an entanglement certification.

A measured joint interaction can be represented within the operational mathematics. Its physical existence, partner selection and causal support are the experimental questions. The first millisecond-scale bench is an exchange test; timing against the light front is a separate qualification. [Bell experiment](https://arxiv.org/abs/1508.05949) · [Quantum non-signalling analysis](https://arxiv.org/abs/quant-ph/0505110)

## Mechanism and conditional predictions

The following construction gives the physical meaning of the operations, a minimal exchange model, its observable signs, competing mechanisms, and the finite domain a null can exclude. The operational mathematics is openly adopted; the post-disconnection coupling is the new physical hypothesis.

### 1. What is added, and what is not

The POAMS motivation is that a completed reciprocal preparation could establish a real relation between retained organizations, rather than merely leave correlated local descriptions. The candidate asks whether some finite capacity for further exchange remains when the enrollment bridge is removed.

Call this **retained adjacency (RA)**. It is not deduced from the graph theorem, whole-turn closure, conservation, PRC, or CCK. In particular, the ratified PRC law requires present completed renewal receipts; two oscillators maintaining their local phases do not supply those receipts. We do not identify an oscillator's ringdown time with the lifetime of a remote relation.

The falsifiable added statement is:

> Within a specified jointly prepared endpoint class and a measured retention interval, physically removing the admitted bridge need not set the effective two-ended exchange amplitude to zero. A source-local boundary phase operation can then change the enrolled terminal's subsequent outcome distribution.

The null model is equally explicit: the post-isolation joint coupling is zero, and each endpoint evolves locally apart from directly bounded ordinary interactions. RA supplies no guaranteed nonzero magnitude, length law, lifetime, or arbitrary-address capability. Those are research unknowns. This is therefore a **model-discriminating test with conditional shape predictions**, not an a priori numerical prediction that a signal must exceed our instrument floor.

The actuator is a source-local detuning pulse: temporarily change the resonator boundary through a characterized tuner so that the accumulated excess phase is +π/2 or −π/2, then restore the same nominal resonance. The pulse changes the phase of actual retained motion. Its work, vibration, heating and emitted spectrum remain in the source/support ledger. Switching a numerical destination label is not an actuator.

### 2. No-signaling boundary

Under the adopted CCK composite and measurement rules, a trace-preserving operation confined to A cannot change B's unconditional state:

\[
\rho'_B=\operatorname{Tr}_A[(\mathcal E_A\otimes I_B)(\rho_{AB})]=\rho_B.
\]

This holds even for an initially correlated or entangled pair. Sorting B's data by a later-revealed A measurement outcome can expose correlations but does not give B a locally readable message.

Consequently the proposed effect requires a **new, nonzero joint interaction**, not an appeal to entanglement. Introducing that interaction is compatible with using CCK to represent a joint channel, but its existence, causal support and physical implementation are additional debts. If a future result is spacelike and controllable, the usual no-superluminal-channel assumption is being challenged. Saying “the old route was not traversed” does not by itself settle that challenge or prevent causal loops.

The present bench experiment does not claim spacelike timing. It asks first whether a late independently randomized setting affects another endpoint after the tested ordinary bridge has been removed.

### 3. Physical and mathematical receipt

| Quantity | Meaning and provenance | Boundary |
|---|---|---|
| A, B, C | Source, enrolled receiver, independently prepared clone receiver | C matches measured local settings but has not exchanged with A during enrollment. Matching cannot be perfect; record its tolerance. |
| a, b | Calibrated complex envelopes of actual retained resonator modes | Operational reduction of I/Q traces; not an unseen carrier. Normalize abs(a)² and abs(b)² to measured stored energy for equal-frequency classical-mode tests. |
| φ | Source-minus-receiver phase after a local detuning operation | Reconstructed using prequalified independent local references; no live shared reference during isolation. |
| θ | Integrated two-ended exchange angle during a declared observation interval | Conditional model parameter, not a physical measurement until independently calibrated from records. |
| g | Exchange-angle rate, θ = gT for the constant-rate example | Measured ordinary value with bridge on; unknown after removal. It is not set equal to its bridge-on value. |
| κ | Energy decay rate from isolated calibration | Amplitude decays at κ/2; include changed loading and uncertainty. |
| q | Fresh terminal challenge binding identity, preparation and trial | Only the part mapped to measured physical settings is a physical address condition. The remaining bits serve authentication. |

The complex two-mode rotation below is an openly adopted CCK-compatible operational representation. Conservation fixes its account structure but does not select θ or prove a coupling.

For matched frequencies and a lossless two-ended settlement interval, choose the coupling-phase reference through an independent connected calibration:

\[
\begin{pmatrix}a'\\b'\end{pmatrix}
=
\begin{pmatrix}\cos\theta&-i\sin\theta\\-i\sin\theta&\cos\theta\end{pmatrix}
\begin{pmatrix}a\\b\end{pmatrix}.
\]

This finite update preserves |a|²+|b|². Its inverse is obtained with −θ. The calculation is a coarse-grained endpoint account; it neither asserts a continuous ontic substrate nor supplies an instantaneous distant operation.

Seed both endpoints with equal initial energy E₀, with a=√E₀ exp(iφ), b=√E₀. Direct algebra gives

\[
\Delta E_B=E_0\sin(2\theta)\sin\phi,\qquad
\Delta E_A=-\Delta E_B.
\]

Thus +π/2 and −π/2 give opposite signed energy redistribution. A calibrated nonzero coupling phase shifts the phase origin; that origin must be frozen from independent calibration or estimated on a separate discovery set, not rotated to maximize the confirmation result. A fully arbitrary post-isolation phase is a different, two-quadrature preregistered test with its own error allocation.

**Global phase is not address selection.** If b=0 instead, E′B=E₀ sin²θ, independent of the global source phase. Multiplying both a and b by the same phase also changes no energy. A proposed “wrong-phase null” must specify which physical relative phase and which populated reference make it meaningful.

### 4. Losses, detuning and finite bandwidth

For the special case of equal independently measured passive loss κ at both endpoints, multiply the update by exp(−κT/2). Against the zero-coupling ringdown baseline,

\[
\Delta E_B^{\rm excess}=e^{-\kappa T}E_0\sin(2gT)\sin\phi.
\]

The lost energy is posted to measured outputs and internal/support loss. Unequal loss, transient detuning, leakage, amplifier backaction and mode mixing require an independently calibrated full trace model. They cannot be hidden inside a fitted “direct-arrival efficiency.”

For a simple passive resonator, an imported calibration model gives

\[
\kappa=\omega_0/Q=2\pi\Delta f,\quad
\tau_E=Q/\omega_0,\quad
\tau_a=2Q/\omega_0.
\]

These relations are engineering reductions, verified by actual ringdown; spectral linewidth alone does not prove useful retained phase. Frequency drift, readout reference error, thermal phase diffusion and multi-mode behavior can make phase retention shorter. Neither classical phase stability nor energy lifetime is automatically a quantum T₂.

The finite-update example is not permission to fit an unbounded g: a large exchange angle can return energy to its original endpoint at the end of a window. Continuous raw traces and multiple preregistered hold times are needed to identify resolved oscillations. Unresolved, delayed or strong-coupling branches stay outside a weak-coupling null bound.

### 5. Competing mechanisms

| Hypothesis | Late source bit at receiver | Clone / history result | Necessary discriminator |
|---|---|---|---|
| Local evolution plus shared preparation | No unconditional effect | Correlated ringdowns can occur at B and C | Source choice generated only after isolation; fixed receiver windows |
| Ordinary residual coupling | Can be present, including the same phase law as RA | Often follows geometry, wiring or spectral matching, but may also depend on preparation | Direct leakage injections, path and enclosure changes, bridge-on calibration; phase dependence alone cannot distinguish it |
| Receiver-local release triggered by a leak | Potentially very large | Depends on receiver stored energy and gain | Passive receiver test, local-store depletion, actuator/readout budgets, bounded information paths |
| Code-only new compatibility channel | Can select compatible local states | Identical clones should be equally eligible absent another distinction | Clone and address-collision trials; cannot claim unique partner choice from a shared code |
| Retained adjacency | Candidate nonzero post-break joint term | Follows prior reciprocal enrollment after local states are matched | Swap enrollment while holding position/code fixed; repeat with erasure and re-enrollment |

RA does not require a particular exponential memory law. Measure g_eff versus elapsed hold time if a channel is found. Local ringdown provides a *validity envelope*, not a witness of g_eff. A model that needs another hidden preparation variable after its stated state is conditioned on must be revised prospectively, not rescued on the confirmation dataset.

**Phase scrambling is not channel erasure.** Randomizing relative phase makes the ensemble mean of the seeded signed term zero even for a real coupling. An unseeded transfer measurement can remain nonzero. Actual energy discharge, deliberate destruction of the retained mode and fresh re-enrollment are distinct interventions and carry distinct interpretation.

### 6. Null and identifiability limits

Let δ_U be a valid upper bound on the absolute normalized +/− receiver contrast after control and uncertainty handling. In the equal-loss, constant-rate, zero-delay, weak-exchange model,

\[
2e^{-\kappa T}|\sin(2gT)|\le\delta_U,
\]

so, **only on the preregistered branch |g|T<π/4**,

\[
|g|\le\frac{\arcsin[\delta_U e^{\kappa T}/2]}{2T}.
\]

If the arcsine argument is ≥1, the measurement supplies no bound on that branch. This bound does not exclude another mode, a longer delay, rapid unresolved exchanges, another preparation, a lower-magnitude channel, or an arbitrary universe-wide claim. Report the actual domain rather than “no portals.”

The same mathematical update with an ordinary g and a hypothesized g has the same endpoint output. **No curve fit can tell those interpretations apart.** Isolation, intervention and countermodel work carry that distinction.

### 7. Conservation and custody are separate gates

For classical microwave standing modes, stored energy is not a measurement of net angular momentum, and E/ω must not be asserted to be their net J. A later handed-mode experiment needs an independently characterized angular-momentum transfer coefficient, full vector signs and support torque/recoil readout.

For a *qualified circular mode only*, the illustrative relation J=E/ω would make 1 pJ at 1.3 GHz correspond to approximately 1.22×10⁻²² J·s. A one-percent transfer would be approximately 1.22×10⁻²⁴ J·s. No sensor has been qualified here to resolve that impulse. This is a real limitation of claiming full angular-momentum closure at the first bench, not permission to infer it from the energy trace.

Likewise, reconstruction of a classical waveform proves only information/state-description transfer. It does not establish physical identity. Source disappearance does not fix that: a destroy-and-copy mechanism is a countermodel. Passing a quantum state-transfer benchmark would establish a stronger channel property, still not transport of a material package. Each custody claim needs a separately declared invariant and witness.

The present constructive result is a **specified physical experiment for the missing edge**, with explicit conditions under which its minimal model succeeds or fails. The existence of that edge remains nature's decision.


## Reproducibility and laboratory handoff

The [full protocol](direct-arrival-protocol.html) and [lab brief](direct-arrival-lab-brief.html) carry the trial sequence, engineering work packages and requested proposal. The downloadable package includes their source text and the complete mechanism construction.

- [Draft preregistration](downloads/direct-arrival/preregistration.json): fixed design choices and 18 instrument-dependent fields for the laboratory to complete before confirmation.
- [Design-check script](downloads/direct-arrival/check_design.py): Python standard library; run beside the preregistration with `python3 check_design.py`.
- [Calculation results](downloads/direct-arrival/design-checks.json): 10/10 arithmetic and structural checks, explicitly marked design calculations rather than sensor records.
- [Package file manifest](downloads/direct-arrival/package-manifest.json): hashes of the public documents, assets and reproducibility files.
- [Complete downloadable package](downloads/direct-arrival-research-package-2026-10-17.zip): exhibits, readable source text and reproducibility material in one archive.

**Current stage:** apparatus qualification and laboratory proposal. Retained adjacency is the proposed extension; the mathematical predictions are conditional on its interaction. Physical qualification and independent experimental review precede a confirmation run. Laboratory cryogenic, RF and electrical procedures govern execution; the protocol also fixes an unknown-channel stop before energy or gain escalation.
